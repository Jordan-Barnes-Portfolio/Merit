using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NoiseGenerator : MonoBehaviour
{
    public int TextureSize;
    public float NoiseScale, IslandSize;
    [Range(1, 20)] public int NoiseOctaves;
    public Texture2D BiomeTexture;
    public string Seed;

    //texture and noise generation
    private void Awake()
    {
        Texture2D tex = new Texture2D(TextureSize, TextureSize);
        GetComponent<Renderer>().sharedMaterial.mainTexture = tex;

        Random.InitState(Seed.GetHashCode());
        Vector2 org = new Vector2(Random.Range(-9999, 9999), Random.Range(-9999, 9999));

        for(int x = 0; x < TextureSize; x++)
        {
            for(int y = 0; y <TextureSize; y++)
            {
                tex.SetPixel(x, y, Noisefunction.FinalNoise(x, y, NoiseOctaves, org, TextureSize, NoiseScale, IslandSize, BiomeTexture));
            }
        }
        tex.Apply();
    }
}
