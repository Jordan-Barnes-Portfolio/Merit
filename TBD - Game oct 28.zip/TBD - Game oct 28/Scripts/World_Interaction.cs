using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class World_Interaction : MonoBehaviour
{

    public Camera cam;

    // Update is called once per frame
    void Update()
    {
       
    }
}
