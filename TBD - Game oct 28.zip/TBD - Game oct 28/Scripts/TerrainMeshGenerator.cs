using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TerrainMeshGenerator : MonoBehaviour
{
    public int xSize = 20;
    public int zSize = 20;
    Mesh mesh;

    Vector3[] vertices;
    int[] triangles;

    // Start is called before the first frame update
    void Start()
    {
        mesh = new Mesh;
        GetComponent<MeshFilter>().mesh = mesh;

        CreateShape();
        UpdateMesh();
    }

    void CreateShape()
    {
        vertices = new Vector3[(xSize + 1) * (zSize + 1)];
    }

    void UpdateMesh()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
